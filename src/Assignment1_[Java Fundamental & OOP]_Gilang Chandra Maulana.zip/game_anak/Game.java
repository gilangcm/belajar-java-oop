package game_anak;

public interface Game {
    void penjumlahan();

    void pengurangan();

    void perkalian();

    void pembagian();

    void belahKetupat ();

    void segitiga ();

    void persegi ();

    void keluar ();


}
